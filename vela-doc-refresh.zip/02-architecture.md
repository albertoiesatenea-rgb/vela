# 02 — Arquitectura de VELA

**Generado:** 2026-04-09 · Verificado contra código real en Replit

---

## Estructura del monorepo

```
workspace/
├── artifacts/
│   ├── silent-closer/          # Frontend React+Vite (VELA UI)
│   │   ├── src/
│   │   │   ├── pages/
│   │   │   │   ├── copilot.tsx     # Modo Copiloto (entry point principal)
│   │   │   │   └── arena.tsx       # Modo Arena (simulación)
│   │   │   ├── components/
│   │   │   │   ├── context-panel.tsx   # Setup, SessionBar, VelaIcon
│   │   │   │   ├── tactical-display.tsx # Display copilot output
│   │   │   │   └── debug-panel.tsx     # AI monitor panel
│   │   │   ├── lib/
│   │   │   │   └── audit-log.ts    # Builders + renderer + BRAND_NAME
│   │   │   └── hooks/
│   │   │       ├── use-speech.ts   # Web Speech API wrapper
│   │   │       └── use-theme.ts    # Dark/light toggle
│   └── api-server/             # Backend Express+TypeScript
│       └── src/
│           ├── routes/
│           │   ├── copilot.ts      # /api/copilot/* endpoints
│           │   └── arena.ts        # /api/arena/* endpoints
│           └── lib/
│               ├── ai-tracker.ts   # Observabilidad AI (tokens, coste, latencia)
│               └── logger.ts       # Pino logger
└── lib/
    └── sales-brain/            # Paquete compartido @workspace/sales-brain
        └── src/
            └── index.ts        # Perfiles, taxonomías, presets, bloques de reglas
```

---

## Paquetes internos

| Paquete | Ruta | Qué exporta |
|---|---|---|
| `@workspace/sales-brain` | `lib/sales-brain/` | CLIENT_PROFILE_DESC, SELLER_PROFILE_DESC, DIFFICULTY_DESC, PRESET_SYSTEM_DESC, DEBRIEF_CLIENT_PROFILE, OBJECTION_TAXONOMY_BLOCK, CLOSING_CRITERIA_BLOCK, SALES_ANTIPATTERNS_BLOCK, COMPARISON_RULE_BLOCK |
| `@workspace/api-zod` | (packages/) | Zod schemas: AnalyzeConversationBody/Response, CallSummarizeBody/Response |
| `@workspace/api-client-react` | (packages/) | Hook `useAnalyzeConversation` |
| `@workspace/integrations-openai-ai-server` | (packages/) | `openai` client singleton |

---

## Flujo de datos — Copiloto

```
Usuario habla/escribe
       ↓
useSpeech / textarea input
       ↓
POST /api/copilot/analyze
  body: { text, context?, call_memory?, lang }
  header: x-session-id
       ↓
gpt-4o-mini → JSON táctico
       ↓
TacticalDisplay (copilot.tsx)
  signal, say_now, avoid, detail, journey, momentum
       ↓
call_memory acumulada en estado React
       ↓
[fin de llamada]
POST /api/copilot/summarize  → score, global_state, strengths, improvements, full_report?
POST /api/copilot/audit-report → BrutalAudit (opcional)
       ↓
buildCopilotAuditLog() → AuditLog → renderAuditLogMarkdown() → descarga .md
```

---

## Flujo de datos — Arena

```
Usuario configura: role, lang, context, clientProfile?, difficulty?, randomPreset?
       ↓
POST /api/arena/start → arenaSessionId, openingMessage
       ↓
[bucle de turnos]
POST /api/arena/turn
  body: { arenaSessionId, message, lang }
  ↓
  gpt-4o-mini → AI response (role inverso)
  ↓ (paralelo, modo seller)
  generateCoachLite() → CoachLite annotation
  ↓ (paralelo, modo client)
  generateJourney() → JourneyData
  ↓
  detectTerminalState() → none | closed | next_step | lost | broken
       ↓
[estado terminal detectado o usuario termina]
POST /api/arena/finish → debrief { score, critique }
       ↓
buildArenaAuditLog() → AuditLog → renderAuditLogMarkdown() → descarga .md
```

---

## Sesiones en memoria (servidor)

Arena usa `Map<string, ArenaSession>` en memoria. No hay persistencia en DB. Las sesiones desaparecen si el servidor se reinicia. El ID de sesión es un UUID generado en `/api/arena/start`.

---

## Fuente de verdad del nombre de marca

```
lib/sales-brain/ → prompts internos (sin brand)
artifacts/silent-closer/src/lib/audit-log.ts → export const BRAND_NAME = "VELA"
  ↳ importado por copilot.tsx → buildSummaryText, buildFullReportText
  ↳ importado por arena.tsx → session report header
  ↳ usado localmente → renderAuditLogMarkdown() → "# VELA AUDIT LOG"
```

Cambiar el nombre de marca: solo hay que editar `BRAND_NAME` en `audit-log.ts`.
