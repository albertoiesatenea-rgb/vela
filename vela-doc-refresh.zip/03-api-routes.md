# 03 — Rutas API de VELA

**Generado:** 2026-04-09 · Verificado contra código real en Replit

Todas las rutas están bajo `/api/`. El servidor API corre en `artifacts/api-server/`.

---

## Copiloto — `artifacts/api-server/src/routes/copilot.ts`

---

### POST /api/copilot/analyze

Analiza un fragmento de conversación y devuelve señal táctica.

**Request body (Zod: AnalyzeConversationBody)**
```json
{
  "text": "fragmento de conversación",
  "context": "contexto de sesión (opcional)",
  "call_memory": "memoria acumulada como string (opcional)",
  "lang": "es | en"
}
```

**Headers opcionales**
```
x-session-id: <uuid>  — para tracking en AI monitor
```

**Response (Zod: AnalyzeConversationResponse)**
```json
{
  "signal": "etiqueta táctica 2-5 palabras",
  "say_now": "jugada táctica 4-12 palabras",
  "avoid": "advertencia 2-7 palabras | null",
  "detail": {
    "reading": "qué está pasando ≤20 palabras",
    "mission": "qué conseguir ahora",
    "next_move": "acción concreta ampliada",
    "support": "dato, argumento o criterio"
  },
  "journey": {
    "past": "fase anterior 2-4 palabras",
    "now": "momento actual 3-6 palabras",
    "next": "siguiente paso 2-4 palabras"
  },
  "call_memory": {
    "summary_lines": ["línea 1", "...", "hasta 6 líneas"]
  },
  "momentum": "green | amber | red"
}
```

**Modelo:** gpt-4o-mini · **max_tokens:** 900  
**Prompt:** V2 (optimizado ~700 tokens) o V1 (legacy ~2100 tokens) según flag LEGACY_PROMPTS  
**Fallback en parse error:** JSON predeterminado con signal="falta claridad", momentum="amber"  
**Tracking:** logAICall() → route="copilot/analyze", endpoint="analyze"

---

### POST /api/copilot/summarize

Genera resumen post-llamada: score, estado global, strengths, improvements. Opcionalmente genera reporte completo.

**Request body (Zod: CallSummarizeBody)**
```json
{
  "call_memory": ["línea 1", "línea 2"],
  "outcome": "closed | next_step | follow | lost | unclear",
  "lang": "es | en",
  "full_report": true
}
```

**Response (Zod: CallSummarizeResponse)**
```json
{
  "score": 7.4,
  "global_state": "sólida | fuerte | ...",
  "result_label": "Siguiente paso acordado",
  "strengths": ["obs 1", "obs 2"],
  "improvements": ["obs 1", "obs 2"],
  "full_report": "texto del reporte | null"
}
```

**Modelo:** gpt-4o-mini  
**max_tokens:** 400 (sin full_report) | 1600 (con full_report)  
**Tracking:** logAICall() → endpoint="summarize" | "summarize-full"

**Scoring (condicional por calidad de ejecución):**
- 8.5-9.5: Cierre real + buena ejecución + sin objeciones técnicas + sin sobrepromesa
- 7.5-8.4: Siguiente paso claro + buena ejecución
- 6.0-7.4: Trabajable, progresos parciales
- 4.0-5.9: Resultado débil, errores relevantes
- 0-3.9: Llamada fallida

**Caps condicionales:**
- next_step + objeción técnica derivada sin resolución → máx 6.5
- next_step + sobrepromesa / garantía falsa → máx 6.5
- next_step con cap: global_state ≠ "fuerte/strong"

---

### POST /api/copilot/audit-report

Auditoría brutal post-sesión. Independiente del flujo de summarize — no hay riesgo de regresión.

**Request body**
```json
{
  "call_memory": ["línea 1", "..."],
  "outcome": "string",
  "context": "contexto (opcional)",
  "lang": "es | en"
}
```

**Response (BrutalAudit)**
```json
{
  "verdict": "string",
  "what_worked": ["string"],
  "what_failed": ["string"],
  "failure_owner": ["vendedor|timing|sistema|técnico|setup|sin fallo real — descripción"],
  "missed_closes": ["string"],
  "rules_violated": ["string"],
  "priority_changes": ["string", "string", "string"],
  "prompt_patch": null,
  "prompt_for_replit": null,
  "what_i_would_have_done": "string",
  "suspected_claim_risk": "yes | no",
  "suspected_unresolved_technical_objection": "yes | no",
  "suspected_false_confidence": "yes | no",
  "suspected_soft_next_step": "yes | no"
}
```

**Modelo:** gpt-4o-mini · **max_tokens:** 900 · **temperature:** 0.3  
**Tracking:** NO registrado en logAICall() — gap conocido  

---

### POST /api/copilot/context-label

Genera un título de escena de 4-6 palabras para la barra de sesión.

**Request body:** `{ context: string, lang: string }`  
**Response:** `{ label: string }`  
**Modelo:** gpt-4o-mini · **max_tokens:** 25  
**Tracking:** logAICall() → endpoint="context-label"

---

## Arena — `artifacts/api-server/src/routes/arena.ts`

---

### POST /api/arena/preset-context

Genera un escenario AI para un preset dado (rol + lang).

**Request body:** `{ preset: string, role: "seller"|"client", lang: "es"|"en" }`  
**Response:** `{ context: string }`  
**max_tokens:** 120 (immvest) | 65 (otros presets) · **temperature:** 0.95

---

### POST /api/arena/adapt-context

Reescribe un contexto existente cambiando la perspectiva del rol (seller ↔ client).

**Request body:** `{ text: string, fromRole: string, toRole: string, lang: string }`  
**Response:** `{ context: string }`  
**max_tokens:** 150 · **temperature:** 0.2

---

### POST /api/arena/start

Crea sesión Arena y genera mensaje de apertura de la IA.

**Request body**
```json
{
  "role": "seller | client",
  "lang": "es | en",
  "context": "string",
  "clientProfile": "analytical|emotional|skeptical|cautious|dominant|indecisive|negotiator",
  "sellerProfile": "string",
  "difficulty": "string",
  "forceTerminal": false,
  "randomPreset": "string"
}
```

**Response:** `{ arenaSessionId: string, openingMessage: string }`  
**max_tokens:** 150 · Modelo: gpt-4o-mini  
**Tracking:** logAICall() → route="arena/start", endpoint="opening"

---

### POST /api/arena/turn

Procesa un turno del usuario y devuelve respuesta AI + opcionalmente coach/journey/terminal.

**Request body:** `{ arenaSessionId: string, message: string, lang: string }`

**Response**
```json
{
  "message": "respuesta AI",
  "outcome": "none | closed | next_step | lost | broken",
  "coach": { "explanation": "3 líneas de anotación" } | null,
  "journey": {
    "stages": { "context":"done", "problem":"current", ... },
    "now_help": "...",
    "next_help": "...",
    "premature_close_risk": "low|medium|high"
  } | null
}
```

**Prompts internos en este endpoint:**
- Sistema principal: buildSystemPrompt() — client persona o seller + reglas
- CoachLite: buildCoachLitePrompt() → max_tokens 280, temperature 0
- Journey: buildJourneyPrompt() → max_tokens 200, temperature 0
- Terminal detection: detectTerminalState() → max_tokens 5, temperature 0

**Windowing de historial (LEGACY_ARENA=false):** solo últimos 12 turnos (6 exchanges) al modelo

---

### POST /api/arena/finish

Cierra sesión y genera debrief.

**Request body:** `{ arenaSessionId: string, outcome: string, lang: string }`  
**Response:** `{ score: number, critique: string[] }`  
**max_tokens:** 300 · **temperature:** 0.2  
**Tracking:** logAICall() → route="arena/finish", endpoint="debrief"

---

### GET /api/debug/usage

Devuelve snapshot de uso AI (debug panel).

**Response:** UsageSnapshot — global totals, routes, sessions (top 20), recentCalls (últimas 50)

---

## Notas transversales

- Todos los endpoints Arena registran `logAICall()` excepto `preset-context` y `adapt-context`
- `audit-report` (copilot) NO registra en logAICall — gap conocido
- El modelo es siempre `gpt-4o-mini` en todos los endpoints
- Todos los endpoints de Arena leen `LEGACY_ARENA` env var para activar optimizaciones
- Todos los endpoints de Copilot leen `LEGACY_PROMPTS` para elegir V1 vs V2
