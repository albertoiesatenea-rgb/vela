# 11 — Sales Brain: Referencias y Taxonomías

**Generado:** 2026-04-09 · Verificado contra código real en Replit

---

## Fuente

`lib/sales-brain/src/index.ts` — paquete `@workspace/sales-brain`  
Fuente de verdad comercial compartida entre Copiloto y Arena.  
**REGLA del módulo:** centralizar definiciones, no instrucciones. Los prompts completos siguen siendo locales en cada ruta.

---

## Perfiles de cliente — `CLIENT_PROFILE_DESC`

Usados en Arena para que la IA juegue el rol del cliente con esta personalidad.

| ID | Descripción |
|---|---|
| `analytical` | Necesitas datos, precisión, proceso y evidencia antes de decidir. Haces preguntas técnicas. Rechazas vaguedades y argumentos emocionales. |
| `emotional` | Decides por confianza, conexión y sensación personal. Te influyen historias reales y la empatía del vendedor. |
| `skeptical` | Desconfías por defecto. Cuestionas promesas, testimonios genéricos y claims inflados. Solo te convencen pruebas concretas y consistencia. |
| `cautious` | Temes equivocarte. Buscas seguridad, validación externa y pasos reversibles. La presión te aleja. |
| `dominant` | Quieres control, velocidad y autoridad. Interrumpes, marcas el ritmo y castigas la debilidad. |
| `indecisive` | Te cuesta comprometerte. Das vueltas, cambias de opinión y necesitas guía clara. |
| `negotiator` | Presionas en precio, comparas alternativas, pides concesiones y usas la negociación como palanca principal. |

---

## Criterios de debrief por perfil — `DEBRIEF_CLIENT_PROFILE`

Orientaciones para el evaluador/coach. Qué penalizar si el vendedor no respondió correctamente al perfil.

| Perfil | Qué se penaliza |
|---|---|
| `analytical` | No responder con concreción (datos, evidencia) cuando el cliente los pide |
| `emotional` | Argumentos fríos o transaccionales |
| `skeptical` | Claims genéricos, testimonios vagos, inconsistencias |
| `cautious` | Presión o urgencia artificial |
| `dominant` | Ceder la dirección de la conversación |
| `indecisive` | Dejar opciones abiertas o ambigüedad |
| `negotiator` | Concesiones tempranas o descuentos sin contraprestación |

---

## Perfiles de vendedor — `SELLER_PROFILE_DESC`

Usados en modo client (IA es el vendedor). El paquete los define; los valores exactos están en el código fuente.

---

## Dificultad — `DIFFICULTY_DESC`

Modifica el nivel de resistencia y complejidad del cliente IA en Arena. Los niveles exactos están en el código fuente.

---

## Presets de escenario — `PRESET_SYSTEM_DESC`

Cada preset tiene descripción ES + EN que se inyecta en el system prompt y en el buildOpeningPrompt.

| Preset ID | Tipo de escenario |
|---|---|
| `immvest` | Inversión inmobiliaria. Escenario detallado (2-3 frases): perfil comprador con capital, objeción principal, fase. max_tokens 120 en preset-context. |
| `challenge` | Escenario absurdo — el cliente claramente no necesita el producto. Requiere precisión con datos concretos. Tropos prohibidos: abrigo tropical, protector solar vampiro, GPS monje. |
| (otros) | Escenarios de venta genérica. 1-2 frases, max_tokens 65. |

---

## Bloque de taxonomía de objeciones — `OBJECTION_TAXONOMY_BLOCK`

Inyectado en el copilot system prompt (V2 y V1). Define la clasificación de señales de duda y tipos de objeción.

**Señales de duda inicial (antes de objeción formada):**
- falta de familiaridad: no conoce el activo/ciudad/marca — no rechaza, simplemente no conoce
- duda abierta: preocupación vaga, criterio no articulado
- necesita criterio: no tiene marco para decidir
- falta confianza inicial: escepticismo de entrada, no rechazo activo
- objeción incipiente: freno que empieza a surgir, no consolidado

**Regla anti-sobrediagnóstico:** "no conozco la ciudad" NO es automáticamente objeción reputacional fuerte.

**Objeción ya formada:**
- real / superficial / falsa / duda genuina
- miedo a equivocarse / miedo a comprometerse
- desconfianza / resistencia emocional
- objeción de precio / liquidez-salida / reputación-zona / timing
- interés real con resistencia de cierre

---

## Bloque de comparaciones — `COMPARISON_RULE_BLOCK`

Inyectado en copilot system prompt. Define cómo manejar comparaciones con alternativas.

**Principio clave:** la alternativa revela el criterio. El criterio es lo que hay que trabajar.

Fases de trabajo:
- FASE A: ¿es la alternativa el centro del problema o revela un criterio?
- FASE B: traducir atributos de la alternativa a criterios de inversión reales
- FASE C: reenfocar esos criterios sobre la propuesta actual
- FASE D: usar datos o argumentos concretos si ya toca
- FASE E: avanzar a validación o cierre si criterios cubiertos

**Prohibición:** si el cliente YA enumeró atributos de la alternativa, está PROHIBIDO volver a preguntar "qué valoras de X". Esa pregunta ya está respondida.

---

## Bloque de criterios de cierre — `CLOSING_CRITERIA_BLOCK`

Inyectado en copilot system prompt. Define cuándo es apropiado el cierre o pregunta cerrada.

Todas estas condiciones deben cumplirse:
1. Objeción principal suficientemente resuelta o aclarada
2. Señales de interés real
3. Sin frentes importantes abiertos
4. La conversación ha madurado
5. El siguiente paso natural es un microcompromiso

Si hay objeción activa, duda difusa, resistencia o falta de criterio: no toca cerrar.

---

## Bloque de anti-patrones — `SALES_ANTIPATTERNS_BLOCK`

Inyectado en el system prompt del vendedor en Arena (modo client). Define patrones prohibidos.

**Reglas incluidas:**
- Coherencia con el contexto: no proponer cambiar variables que el contexto ya define como fijas
- Objeción repetida: ir al umbral o reconocer el bloqueo, no responder con argumentos laterales ya aceptados
- Marcos descartados: si el cliente rechazó explícitamente un tipo de argumento (largo plazo, revalorización, ventaja fiscal), ese marco está quemado para el resto de la conversación — no se retoma
- Conclusión ya dicha: si ya se afirmó que la operación no encaja, no mandar otro mensaje ampliando la misma idea
- Umbral definido: si el cliente define un umbral concreto (precio, condición), ese umbral es el eje de la conversación

---

## Filosofía comercial implícita en el código

1. **Precisión sobre persuasión genérica** — los clientes analíticos son tratados como caso diferenciado y explícito
2. **El criterio del cliente es el eje** — no el argumento del vendedor
3. **La alternativa revela el criterio** — no se entra en debate de comparación directa
4. **Anti-repetición es ley** — el modelo debe avanzar si el cliente ya respondió
5. **El umbral es inmutable** — si el cliente define una condición, el vendedor no puede diluirla
6. **Honestidad sobre el encaje** — si la operación no encaja, se dice con claridad. No se sigue vendiendo lo que no funciona
