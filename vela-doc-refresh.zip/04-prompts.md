# 04 — Prompts de VELA

**Generado:** 2026-04-09 · Verificado contra código real en Replit

Todos los prompts están en el servidor (`artifacts/api-server/src/routes/`).  
Los bloques de reglas compartidos vienen de `@workspace/sales-brain`.

---

## Copiloto — Sistema principal (V2 optimizado, activo por defecto)

**Archivo:** `copilot.ts` → `BASE_SYSTEM_PROMPT_V2`  
**Activación:** `LEGACY_PROMPTS !== "true"` (default)  
**~700 tokens** (vs ~2100 del V1)

### Contenido resumido

```
Eres copiloto táctico silencioso para conversaciones de venta en tiempo real.
Recibes fragmentos entre Persona A (vendedor) y Persona B (cliente).

SCHEMA — JSON exacto, sin markdown:
{signal, say_now, avoid, detail:{reading, mission, next_move, support},
 journey:{past, now, next}, call_memory:{summary_lines:[]}, momentum}

CAMPOS — cada uno dice algo distinto:
- signal = TIPO de situación
- reading = QUÉ está pasando (diagnóstico)
- mission = QUÉ CONSEGUIR ahora (propósito táctico)
- next_move = acción concreta inmediata
- journey.now = dónde está la conversación en su arco
- say_now = QUÉ DICES O HACES (imperativo, 4-12 palabras)

CLASIFICACIÓN PREVIA (A/B/C):
A) Cliente con duda → reacción táctica
B) Vendedor explicando correcto → no proponer pregunta genérica
C) Ruido/ambigüedad → microaclaración específica

DETECCIÓN DE RIESGO (antes de say_now):
- CLAIM_RISK: vendedor usa "garantía", "certific", "te aseguro", "sin duda", "100% seguro"
- FALSE_CONFIDENCE: usa certificación/auditoría como prueba definitiva
- UNRESOLVED_TECHNICAL_OBJ: cliente pide datos, vendedor responde genérico
- ANALYTICAL_BUYER: cliente pide datos/evidencia → responder con precisión

ANTI-REPETICIÓN:
Determina caso (1-5) antes de say_now. Caso 1 = AVANZA, prohibido repetir jugada.

[+ OBJECTION_TAXONOMY_BLOCK, COMPARISON_RULE_BLOCK, CLOSING_CRITERIA_BLOCK desde sales-brain]

CALL_MEMORY: 4-6 líneas tácticas. Reescribe cada turno. No crecer.
MOMENTUM: green=interés real+apertura / amber=objeción trabajable / red=resistencia alta
```

**Inyecciones dinámicas (buildSystemPrompt()):**
- `CONTEXTO DE SESIÓN: <context>` si hay contexto de sesión
- `IDIOMA: La llamada es en español.` o `LANGUAGE: The call is in English.`

---

## Copiloto — Sistema principal (V1 legacy)

**Activación:** `LEGACY_PROMPTS=true`  
**~2100 tokens**  
Mismos campos y reglas que V2 pero con formato más verboso, más ejemplos, más separadores visuales (━━━). Mantenido para diagnóstico y comparación.

---

## Copiloto — Summarize

**Archivo:** `copilot.ts` → `systemPrompt` en `/api/copilot/summarize`  
**Modelo:** gpt-4o-mini · **max_tokens:** 400 (sin full_report) | 1600 (con)

El prompt devuelve JSON:
```json
{"score":7.4,"global_state":"sólida","result_label":"...","strengths":[],"improvements":[],"full_report":null}
```

Incluye rúbrica de scoring con caps condicionales:
- Objeción técnica derivada → cap 6.5
- Sobrepromesa → cap 6.5
- Sin criterio de decisión acordado → penalizar, global_state ≠ "fuerte"

**Full report sections (cuando se solicita):**
```
Resumen ejecutivo | Lo que se hizo bien | Lo que se puede mejorar |
Objeciones o riesgos detectados | Control de la conversación |
Cierre / siguiente paso | Recomendación para la próxima llamada
```

---

## Copiloto — Audit Report (brutal)

**Archivo:** `copilot.ts` → `systemPrompt` en `/api/copilot/audit-report`  
**Modelo:** gpt-4o-mini · **max_tokens:** 900 · **temperature:** 0.3

Schema de respuesta:
```json
{
  "verdict": "string",
  "what_worked": ["string"],
  "what_failed": ["string"],
  "failure_owner": ["vendedor|timing|sistema|técnico|setup|sin fallo real — descripción"],
  "missed_closes": ["string"],
  "rules_violated": ["string"],
  "priority_changes": ["string", "string", "string"],
  "prompt_patch": null,
  "prompt_for_replit": null,
  "what_i_would_have_done": "string",
  "suspected_claim_risk": "yes|no",
  "suspected_unresolved_technical_objection": "yes|no",
  "suspected_false_confidence": "yes|no",
  "suspected_soft_next_step": "yes|no"
}
```

Risk flags — definiciones en el prompt:
- `suspected_claim_risk`: "guarantee", "certified", "I assure you", "100% safe", "no risk" como argumento principal sin evidencia
- `suspected_unresolved_technical_objection`: objeción técnica derivada a documentación o respondida genéricamente
- `suspected_false_confidence`: certificación oficial / organismo regulador usados como prueba definitiva
- `suspected_soft_next_step`: siguiente paso sin criterio de decisión acordado para la próxima llamada

---

## Copiloto — Context Label

**max_tokens:** 25  
Devuelve 4-6 palabras como título de escena para la barra de sesión.  
Ejemplo: "Venta a inversor escéptico sobre Dresden"

---

## Arena — Sistema principal (buildSystemPrompt)

**Archivo:** `arena.ts`  
**Modo seller** (IA es el cliente):
```
Eres el cliente/prospecto en una simulación de conversación de venta.
Contexto: <context>
PERSONALIDAD: <CLIENT_PROFILE_DESC[clientProfile]>
DIFICULTAD: <DIFFICULTY_DESC[difficulty]>
[preset block si randomPreset]
[window note si historial > 12 turnos]
Tu papel es la otra parte. Mantén tu personalidad consistente.
Responde 1-3 frases naturales. **negrita** para objeciones clave.
```

**Modo client** (IA es el vendedor):
```
Eres el vendedor en una simulación. Actúas como comercial experimentado.
Contexto: <context>
RESTRICCIONES DEL VENDEDOR (si hay sellerNotes): <lista>
[preset block si randomPreset]

MOVIMIENTOS DISPONIBLES — exactamente uno por turno:
1. Diagnosticar con pregunta concreta
2. Responder directo y breve
3. Identificar umbral concreto
4. Admitir con honestidad que no encaja

[Reglas de umbral, coherencia, objeción repetida, marcos descartados, conclusión dicha]
[SALES_ANTIPATTERNS_BLOCK]
[Reglas de formato y tono]
```

---

## Arena — Apertura (buildOpeningPrompt)

**max_tokens:** 150  
**Modo seller** (IA abre como cliente): No genera apertura de vendedor — el usuario escribe primero.  
**Modo client** (IA es vendedor que abre): Una frase. Vendedor inventa nombre+empresa reales concretos. Varía: observación, referencia al problema, gancho, pregunta. **Nunca explica el producto.**

---

## Arena — CoachLite (buildCoachLitePrompt)

**max_tokens:** 280 · **temperature:** 0  
Formato obligatorio — exactamente 3 líneas:
```
**Nombre táctico** (2-4 palabras en negrita)
- qué hace o detecta el vendedor (≤7 palabras)
- por qué funciona o qué objetivo consigue (≤7 palabras)
```
Solo activo en modo seller (usuario es vendedor, IA es cliente).

---

## Arena — Journey (buildJourneyPrompt)

**max_tokens:** 200 · **temperature:** 0  
Analiza últimos 10 turnos. Devuelve JSON:
```json
{
  "stages": {
    "context": "done|current|upcoming",
    "problem": "...",
    "blocker": "...",
    "fit": "...",
    "advance": "...",
    "close": "..."
  },
  "now_help": "qué intenta conseguir el vendedor ahora",
  "next_help": "qué necesita ocurrir para avanzar",
  "premature_close_risk": "low|medium|high"
}
```
Solo activo en modo client (usuario es cliente, IA es vendedor).

---

## Arena — Terminal Detection (detectTerminalState)

**max_tokens:** 5 · **temperature:** 0  
Solo activo en modo seller (no en client — `if (role === "client") return "none"`).  

Responde UNA de: `none | closed | next_step | lost | broken`

Definiciones estrictas:
- `closed`: cliente cerró explícitamente (firma, pago)
- `next_step`: cliente COMPROMETIÓ paso concreto (fecha, contrato, disponibilidad) — "lo pensaré" NO califica
- `lost`: rechazo definitivo
- `broken`: ruptura total

Se ejecuta cuando (`shouldCheckTerminal`):
- turno ≥ 4 Y (turno ≥ 6 Y turno % 3 === 0) → safety net cada 3 turnos
- O el último mensaje AI contiene keywords de `TERMINAL_HINTS`

---

## Arena — Debrief (generateDebrief)

**max_tokens:** 300 · **temperature:** 0.2  
Responde JSON: `{ score: 1-10, critique: ["frase 1", "frase 2", "frase 3"] }`

Caps iguales a summarize de copiloto. Si historial > 15 turnos, solo analiza últimos 15 (`DEBRIEF_MAX_TURNS`).

---

## Arena — Preset Context

Dos variantes de prompt:
- **immvest** (inmobiliario): 2-3 frases detalladas, perfil comprador con capital/objeción/fase
- **otros presets**: 1-2 frases cortas, directo

`challenge` preset incluye restricción adicional: el escenario DEBE ser absurdo y preciso (no tropos genéricos).

---

## Arena — Adapt Context

Reescribe perspectiva del contexto (seller ↔ client), manteniendo todos los detalles concretos.  
**max_tokens:** 150 · **temperature:** 0.2
