# 05 — Lógica del modo Arena

**Generado:** 2026-04-09 · Verificado contra código real en Replit

---

## Ciclo de vida de una sesión Arena

```
1. SETUP (frontend)
   usuario configura: role, lang, context, clientProfile?, difficulty?,
   randomPreset?, sellerNotes[]

2. POST /api/arena/start
   → crea ArenaSession en Map<string, ArenaSession> (en memoria)
   → genera openingMessage (gpt-4o-mini, max_tokens 150)
   → modo seller: IA abre como cliente
   → modo client: IA abre como vendedor (con nombre+empresa inventados)

3. BUCLE DE TURNOS (POST /api/arena/turn)
   usuario escribe mensaje
   → IA responde (gpt-4o-mini)
   → [paralelo, modo seller] CoachLite annotation
   → [paralelo, modo client] Journey update
   → terminal detection (si aplica)
   → si outcome ≠ "none" → conversación terminada automáticamente

4. FIN (POST /api/arena/finish)
   → genera debrief { score, critique }
   → frontend recibe debrief y muestra pantalla de resultado

5. DESCARGA (frontend)
   buildArenaAuditLog() → renderAuditLogMarkdown() → .md
```

---

## Roles

| Rol de usuario | IA juega | Coach | Journey |
|---|---|---|---|
| seller | cliente/prospecto | ✅ CoachLite activo | ❌ Journey desactivado |
| client | vendedor experto | ❌ CoachLite desactivado | ✅ Journey activo |

---

## Perfiles de cliente (`clientProfile`)

Definidos en `@workspace/sales-brain` → `CLIENT_PROFILE_DESC`:

| ID | Comportamiento |
|---|---|
| `analytical` | Necesita datos, precisión, evidencia. Rechaza vaguedades. |
| `emotional` | Decide por confianza, conexión personal, empatía. |
| `skeptical` | Desconfía por defecto. Solo convencen pruebas concretas. |
| `cautious` | Teme equivocarse. Busca seguridad, pasos reversibles. La presión lo aleja. |
| `dominant` | Quiere control y velocidad. Castiga la indecisión. |
| `indecisive` | Le cuesta comprometerse. Necesita guía clara. |
| `negotiator` | Presiona en precio, compara alternativas, exige concesiones. |

**Aliases de compatibilidad** (resueltos en `/api/arena/start`):
- `insecure` → `cautious`
- `hard_negotiator` → `negotiator`
- `random` / `aleatorio` → `undefined` (sin perfil específico)

---

## Perfiles de vendedor (`sellerProfile`)

Definidos en `@workspace/sales-brain` → `SELLER_PROFILE_DESC`. Activos en modo client (IA es vendedor).

---

## Dificultad (`difficulty`)

Definida en `@workspace/sales-brain` → `DIFFICULTY_DESC`. Modifica el comportamiento del cliente IA.

---

## Presets de escenario (`randomPreset`)

Definidos en `@workspace/sales-brain` → `PRESET_SYSTEM_DESC`.  
Cada preset tiene descripción en ES+EN que se inyecta en el system prompt y en el buildOpeningPrompt.

Preset especial:
- **`immvest`**: Escenarios inmobiliarios de inversión. Contexto generado en 2-3 frases detalladas con perfil de comprador (profesión, capital, objeción principal, fase). max_tokens 120 en preset-context.
- **`challenge`**: Escenarios absurdos donde el cliente claramente no necesita el producto. La precisión (datos concretos) hace el absurdo creíble. Tropos prohibidos: abrigo en ciudad tropical, protector solar a vampiro, GPS a monje.

---

## Detección de estado terminal

**Solo en modo seller.** En modo client siempre devuelve "none".

### Cuándo se activa (`shouldCheckTerminal`)
1. Turno ≥ 4 Y (turno ≥ 6 Y turno % 3 === 0) → safety net automático cada 3 turnos
2. O el último mensaje AI contiene keywords de `TERMINAL_HINTS`

### Keywords ES
```
trato hecho, cerramos, firmamos, me lo quedo, me apunto, lo compro,
cuándo firmo, cuándo firma, voy a pagar, pago con, con tarjeta, bizum,
mándame el contrato, mándame la propuesta, cuando quieras empezamos,
no me interesa en absoluto, definitivamente no, no voy a comprar,
no quiero saber más, hasta aquí, no seguimos, adiós, hasta luego
```

### Keywords EN
```
deal, let's close, i'll take it, i'll buy, send me the contract,
when do i sign, i'll pay with, by card, send the proposal,
not interested at all, definitely not, won't buy, stop here,
goodbye, bye
```

### Prompt de detección
max_tokens: 5, temperature: 0. Responde UNA palabra.  
Definiciones estrictas — en caso de duda: `none`.

### Outcomes posibles
- `none` — conversación abierta
- `closed` — cliente cerró explícitamente
- `next_step` — compromiso concreto (fecha, contrato, disponibilidad)
- `lost` — rechazo definitivo
- `broken` — ruptura total
- `manual_stop` — usuario terminó manualmente (no del modelo)

---

## CoachLite (modo seller)

Anotación táctica de cada intercambio. Formato 3 líneas exactas:
```
**Nombre táctico**
- qué hace o detecta el vendedor (≤7 palabras)
- por qué funciona (≤7 palabras)
```
gpt-4o-mini, max_tokens: 280, temperature: 0.  
**latencyMs hardcodeado a 0** en logAICall — gap conocido.

---

## Journey tracker (modo client)

Analiza últimos 10 turnos. Clasifica 6 etapas:

| Etapa | Descripción |
|---|---|
| `context` | Vendedor estableció marco y qué vende |
| `problem` | Vendedor identificó necesidad/fricción |
| `blocker` | Vendedor identificó qué frena la decisión |
| `fit` | Vendedor conectó solución con bloqueo concreto |
| `advance` | Cliente mostró interés real o acordó paso |
| `close` | Cliente tomó decisión firme |

Cada etapa: `"done" | "current" | "upcoming"`. Exactamente 1 es "current".  
gpt-4o-mini, max_tokens: 200, temperature: 0.  
**latencyMs hardcodeado a 0** en logAICall — gap conocido.

---

## Instrucciones runtime ocultas (sellerNotes)

En modo client, el trainer (usuario) puede inyectar restricciones al vendedor AI en tiempo real. Se almacenan en `ArenaSession.sellerNotes[]` y se inyectan en el system prompt como:

```
RESTRICCIONES DEL VENDEDOR (aplica SIEMPRE — no negociable, sin excepciones):
1. <instrucción>
2. <instrucción>
```

Son visibles en el audit log bajo `## HIDDEN_RUNTIME_INSTRUCTIONS` con comentario explicativo.

---

## Windowing de historial (optimización)

`LEGACY_ARENA=false` (default): solo últimos 12 turnos (`ARENA_HISTORY_WINDOW = 12`) se envían al modelo en cada turno. Si el historial supera ese límite, el prompt incluye una nota:
```
[Conversación de N turnos totales. Se muestran solo los últimos 12 por eficiencia.
Mantén coherencia con tu personalidad y el contexto asignados.]
```

`LEGACY_ARENA=true`: historial completo sin windowing.

---

## Límites de turns en sub-llamadas

| Sub-llamada | Límite de turns enviados |
|---|---|
| Debrief | `DEBRIEF_MAX_TURNS = 15` (últimos 15 si sesión > 15) |
| Suggest | `SUGGEST_MAX_TURNS = 10` |
| Journey | últimos 10 turns |
| Terminal detection | últimos 6 turns |

---

## Debrief — Rúbrica

1. Pesa outcome Y calidad de ejecución por igual
2. Cap duro ≤ 7 si el comprador repite demanda central 2+ veces sin resolución concreta del vendedor
3. Penalizaciones (-1 a -2 c/u): proponer reunión antes de resolver objeción · siguiente paso ambiguo sin fecha · repetir misma estructura de respuesta
4. Sensibilidad al perfil: aplica criterio del perfil del comprador
5. Referencias: closed vs cliente difícil → mín 8; lost/broken → máx 5; next_step buena ejecución → hasta 8; débil → 5-6

---

## Persistencia

**No hay DB.** Las sesiones viven en `Map<string, ArenaSession>` en memoria del proceso. Si el servidor se reinicia, todas las sesiones se pierden. Las sesiones de sessionStore (ai-tracker) se eliminan automáticamente 10 min después del cierre.
