# 09 — Feature Flags

**Generado:** 2026-04-09 · Verificado contra código real en Replit

---

## Variables de entorno que actúan como feature flags

---

### `LEGACY_PROMPTS`

**Archivo:** `artifacts/api-server/src/routes/copilot.ts`

```typescript
const USE_OPTIMIZED_PROMPTS = process.env["LEGACY_PROMPTS"] !== "true";
```

| Valor | Comportamiento |
|---|---|
| no definida / `"false"` (default) | Usa `BASE_SYSTEM_PROMPT_V2` (~700 tokens, optimizado) |
| `"true"` | Usa `BASE_SYSTEM_PROMPT_V1` (~2100 tokens, verbose legacy) |

**Qué cambia con V2 vs V1:**
- V2: mismo contenido táctico, comprimido, sin decoradores visuales (━━━), menos prose redundante
- V1: formato verboso con separadores, más ejemplos explícitos, más largo
- El schema de respuesta JSON es idéntico en ambos
- Las reglas tácticas (anti-repetición, clasificación, risk flags, etc.) están en ambos

**Cuándo usar V1:** diagnóstico de problemas de adherencia al schema o cuando se sospecha que el modelo necesita más contexto explícito.

---

### `LEGACY_ARENA`

**Archivo:** `artifacts/api-server/src/routes/arena.ts`

```typescript
const USE_OPTIMIZED_ARENA = process.env["LEGACY_ARENA"] !== "true";
```

| Valor | Comportamiento |
|---|---|
| no definida / `"false"` (default) | Modo optimizado: windowing + terminal detection condicional |
| `"true"` | Modo legacy: historial completo + terminal detection en cada turno |

**Qué cambia:**

1. **Windowing de historial** (LEGACY_ARENA=false):
   - Solo últimos `ARENA_HISTORY_WINDOW = 12` turnos al modelo
   - Ahorra tokens en sesiones largas
   - El prompt incluye nota de truncado para el modelo

2. **Terminal detection condicional** (LEGACY_ARENA=false):
   - `shouldCheckTerminal()` decide si lanzar la llamada extra
   - Condición: turno ≥ 4 Y (turno ≥ 6 Y turno % 3 === 0) OR keyword match
   - Evita la llamada de detección en cada turno → ahorra tokens

3. **Debrief** (LEGACY_ARENA=false):
   - Solo últimos `DEBRIEF_MAX_TURNS = 15` turnos al modelo de debrief

**Cuándo usar LEGACY:** sesiones donde la IA pierde el hilo de su personalidad, o cuando se sospecha que el truncado afecta la coherencia.

---

## Constantes de configuración (no son env vars, están en código)

| Constante | Valor | Archivo | Descripción |
|---|---|---|---|
| `ARENA_HISTORY_WINDOW` | 12 | arena.ts | Turns máximos enviados al modelo por turno |
| `DEBRIEF_MAX_TURNS` | 15 | arena.ts | Turns máximos enviados al debrief |
| `SUGGEST_MAX_TURNS` | 10 | arena.ts | Turns máximos enviados a suggest |
| `RECENT_CALLS_LIMIT` | 200 | ai-tracker.ts | Tamaño del ring buffer de llamadas |

---

## Variables de entorno requeridas (no son flags — son secretos)

| Variable | Propósito |
|---|---|
| `SESSION_SECRET` | Secret para sesiones Express |
| OpenAI API key | Configurada via `@workspace/integrations-openai-ai-server` |

---

## Notas

- No hay flags de UI en el frontend (todo comportamiento de UI es hardcodeado)
- No hay flags por usuario ni por sesión — los flags son globales del proceso
- Los flags se leen en el momento de arranque del proceso (no hot-reload)
