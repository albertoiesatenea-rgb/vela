# 06 — AI Tracking y Observabilidad

**Generado:** 2026-04-09 · Verificado contra código real en Replit

---

## Archivo fuente

`artifacts/api-server/src/lib/ai-tracker.ts`

---

## Qué hace

Capa centralizada de observabilidad para cada llamada OpenAI. Registra tokens, coste estimado y latencia. Agrega por sesión y por ruta. Sin base de datos — todo en memoria. Expuesto en `/api/debug/usage` (debug panel).

---

## Modelo de precios configurado

```typescript
const MODEL_PRICING = {
  "gpt-4o-mini": { input: 0.00015, output: 0.0006 },  // $0.15 / $0.60 per 1M tokens
  "gpt-4o":      { input: 0.0025,  output: 0.01   },
  "gpt-4":       { input: 0.03,    output: 0.06   },
  "gpt-4-turbo": { input: 0.01,    output: 0.03   },
};
```
Si el modelo no está en la tabla → `estimatedCostUsd = null`.

---

## Tipos exportados

### `AiUsageRecord`
```typescript
{
  callId:               string      // UUID único por llamada
  timestamp:            string      // ISO
  route:                string      // "copilot/analyze", "arena/start", ...
  endpoint:             string      // nombre lógico del endpoint
  mode:                 "copilot" | "arena"
  sessionId?:           string
  model:                string
  maxTokensConfigured:  number
  promptTokens:         number
  completionTokens:     number
  totalTokens:          number
  estimatedCostUsd:     number | null
  latencyMs:            number
  status:               "ok" | "error" | "partial"
  notes?:               string      // parse errors, fallbacks, retries
}
```

### `SessionUsageSummary`
```typescript
{
  sessionId, mode, calls,
  totalPromptTokens, totalCompletionTokens, totalTokens,
  totalCostUsd, avgLatencyMs, createdAt, lastCallAt
}
```

### `RouteUsageSummary`
```typescript
{
  route, calls, totalTokens, totalCostUsd,
  avgLatencyMs, avgPromptTokens, avgCompletionTokens
}
```

---

## Función principal — `logAICall(params)`

Registra una llamada AI. Se llama en cada endpoint que invoca OpenAI.

```typescript
logAICall({
  route:               "copilot/analyze",
  endpoint:            "analyze",
  mode:                "copilot",
  sessionId?:          string,
  model:               "gpt-4o-mini",
  maxTokensConfigured: 900,
  promptTokens:        usage.prompt_tokens,
  completionTokens:    usage.completion_tokens,
  totalTokens:         usage.total_tokens,
  latencyMs:           Date.now() - t0,
  status:              "ok" | "error" | "partial",
  notes?:              string,
});
```

### Efectos de `logAICall()`:
1. Añade al ring buffer `recentCalls[]` (max 200 registros)
2. Actualiza `global` totals (calls, totalTokens, totalCostUsd)
3. Actualiza `routeStore` por ruta (rolling averages)
4. Si hay sessionId: actualiza `sessionStore` por sesión
5. Emite línea de log Pino: `[AI] route:endpoint | in=X out=Y | $Z | Wms`

---

## Almacenamiento en memoria

```
recentCalls[]            — ring buffer, máx 200, FIFO
sessionStore Map<id, SessionUsageSummary>  — sesiones activas (se eliminan 10 min tras cierre)
routeStore Map<route, RouteUsageSummary>   — agregados permanentes (vida del proceso)
global {}                — totales globales (vida del proceso)
```

---

## Snapshot para debug — `getUsageSnapshot()`

Devuelve:
- `serverStartedAt`: ISO timestamp de inicio del proceso
- `global`: { calls, totalTokens, totalCostUsd }
- `routes[]`: ordenados por totalCostUsd desc, con averages redondeados
- `sessions[]`: top 20 por totalCostUsd desc
- `recentCalls[]`: últimas 50, orden inverso (más reciente primero)

---

## Endpoints que registran en `logAICall()`

| Ruta | Endpoint lógico | ¿Registra? |
|---|---|---|
| copilot/analyze | analyze | ✅ |
| copilot/summarize | summarize / summarize-full | ✅ |
| copilot/context-label | context-label | ✅ |
| copilot/audit-report | — | ❌ gap conocido |
| arena/start | opening | ✅ |
| arena/turn → AI response | turn | ✅ |
| arena/turn → coach-lite | coach-lite | ✅ (latencyMs=0) |
| arena/turn → journey | journey | ✅ (latencyMs=0) |
| arena/turn → terminal | terminal-state | ✅ |
| arena/finish → debrief | debrief | ✅ |
| arena/preset-context | — | ❌ (sin sessionId tampoco) |
| arena/adapt-context | — | ❌ |

---

## Otras funciones exportadas

```typescript
closeSession(sessionId: string): void
// Emite log de sesión total y programa eliminación de sessionStore en 10 min

getSessionStats(sessionId: string): SessionUsageSummary | undefined
// Para debug panel

estimateModelCost(model, promptTokens, completionTokens): number | null
// Cálculo de coste estimado
```

---

## Formato de log Pino

Cada llamada produce una línea info:
```json
{
  "ai_usage": true,
  "callId": "...",
  "route": "copilot/analyze",
  "endpoint": "analyze",
  "sessionId": "...",
  "mode": "copilot",
  "model": "gpt-4o-mini",
  "prompt_tokens": 850,
  "completion_tokens": 320,
  "total_tokens": 1170,
  "cost_usd": 0.000319,
  "latency_ms": 1240,
  "status": "ok",
  "notes": null
}
```

Al cerrar sesión:
```json
{
  "ai_session_total": true,
  "sessionId": "...",
  "mode": "arena",
  "calls": 14,
  "total_tokens": 8450,
  "cost_usd": 0.002345
}
```
