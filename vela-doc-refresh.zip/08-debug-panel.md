# 08 — Debug Panel (AI Monitor)

**Generado:** 2026-04-09 · Verificado contra código real en Replit

---

## Archivo fuente

`artifacts/silent-closer/src/components/debug-panel.tsx` (588 líneas)

---

## Qué es

Panel de monitorización de coste y tokens AI. Disponible en Copiloto y Arena. Táctico, no decorativo. Diseño dark puro, fuente mono.

---

## Cómo abrirlo

- Botón `AI $` (esquina inferior derecha)
- Atajo de teclado: **Ctrl+Shift+D**

---

## Persistencia (localStorage)

```typescript
const LS_PINNED = "cwiz-debug-pinned";  // panel pinado (no se cierra)
const LS_OPEN   = "cwiz-debug-open";    // panel abierto
const LS_DETAIL = "cwiz-debug-detail";  // vista detalle expandida
```

---

## Fuente de datos

`GET /api/debug/usage` — polling cada 4 segundos cuando el panel está abierto.

---

## KPIs que muestra

**Header principal:**
- Total calls (global)
- Total tokens (global, formateado como "12.4k")
- Total coste USD (global)
- Avg latencia global

**Por sesión activa:**
- sessionId (7 caracteres)
- calls / tokens / coste / avg latencia
- Alert level: NORMAL / VIGILAR / CARA / LATENCIA ALTA

**Por ruta:**
- Nombre de ruta
- Calls, tokens, coste, avg latencia, avg prompt/completion tokens

**Llamadas recientes (últimas 50, orden inverso):**
- callId, timestamp, route, endpoint, model
- tokens (prompt/completion/total)
- coste estimado
- latencia
- status (ok/error/partial)
- notes si hay

---

## Sistema de alertas por sesión

```typescript
function getAlert(session: SessionStats): AlertInfo
```

| Nivel | Condición | Color |
|---|---|---|
| `LATENCIA ALTA` | avgLatencyMs > 2000 | sky-400 |
| `CARA` | totalCostUsd > 0.05 | amber-300 |
| `VIGILAR` | totalCostUsd > 0.015 OR avgLatencyMs > 1400 OR calls > 25 | amber-400 |
| `NORMAL` | ninguna anterior | zinc-500 |

---

## Detección de ruta dominante

```typescript
function getDominantRoute(routes: RouteStats[]): string | null
```
Si una ruta genera >70% del coste total → se muestra en el header como "ruta que más gasta".

---

## Heavy call detection

```typescript
const HEAVY_ABS   = 900;   // tokens — floor absoluto
const HEAVY_MULT  = 1.75;  // multiplicador sobre avg de sesión
const HEAVY_MIN_N = 3;     // mínimo de calls antes de usar threshold relativo
```
Una llamada es "heavy" si supera el floor absoluto Y (si hay ≥3 calls previos) es HEAVY_MULT veces el avg de sesión.

---

## Formatters internos

| Función | Input | Output ejemplo |
|---|---|---|
| `fmt$(v)` | number\|null | "$0.0003" / "$0" / "?" |
| `fmtK(v)` | number | "12.4k" / "850" |
| `fmtMs(ms)` | number | "1.2s" / "340ms" |
| `fmtTime(iso)` | string ISO | "14:30:22" |
| `shortId(id)` | uuid | "3f7a1b2" |
| `routeLabel(route)` | "copilot/analyze" | "analyze" |

---

## Notas de diseño

- Fondo pure black (`bg-black`)
- Fuente monoespaciada en todos los valores
- Pinnable: si está pinado, no se cierra al hacer clic fuera
- El panel no afecta el comportamiento de la app — es observación pura
- Las llamadas de `audit-report` NO aparecen en el panel (gap conocido en ai-tracker)
- Las latencias de `coach-lite` y `journey` aparecen como 0ms (gap conocido)
