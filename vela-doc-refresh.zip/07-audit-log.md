# 07 — Sistema de Audit Log

**Generado:** 2026-04-09 · Verificado contra código real en Replit

---

## Archivo fuente

`artifacts/silent-closer/src/lib/audit-log.ts` (911 líneas)

---

## Constante de marca

```typescript
export const BRAND_NAME = "VELA" as const;
```
Usada en:
- `renderAuditLogMarkdown()` → `# VELA AUDIT LOG`
- `copilot.tsx` → `buildSummaryText()`, `buildFullReportText()`
- `arena.tsx` → session report header

---

## Pipeline

```
Raw session data
       ↓
buildCopilotAuditLog(CopilotSessionData)  [modo copiloto]
buildArenaAuditLog(ArenaSessionData)      [modo arena]
       ↓
AuditLog (typed object)
       ↓
renderAuditLogMarkdown(AuditLog)
       ↓
.md file (descargado via triggerAuditLogDownload)
```

---

## Estructura AuditLog

```typescript
interface AuditLog {
  meta:               SessionMeta
  context:            SessionContext
  config:             SessionConfig
  turns:              AuditTurn[]
  readable_transcript: string[]
  summary:            SessionSummary
  audit_hints:        AuditHints
}
```

---

## SessionMeta

```typescript
{
  app_mode:              "copilot" | "arena"
  session_id:            string | null
  exported_at:           string   // ISO timestamp
  app_version:           "1.0.0"  // hardcodeado
  model:                 "gpt-4o-mini"
  lang:                  "es" | "en"
  ui_mode:               "copilot" | "arena"
  source_mode:           "listen" | "simulate" | "mixed" | "chat"
  speaker_mode_default:  "auto" | "client" | "me" | null
  role_in_arena:         "seller" | "client" | null
  context_label:         string | null   // título AI de 4-6 palabras
  session_status:        string          // outcome declarado
}
```

---

## SessionContext

```typescript
{
  raw_context:       string
  objective:         null   // SIEMPRE null — no se extrae automáticamente
  known_objections:  null   // SIEMPRE null — gap conocido
  relevant_data:     null   // SIEMPRE null — gap conocido
}
```

---

## SessionConfig

```typescript
{
  input_mode:              string | null
  speaker_mode_default:    string | null
  arena_role:              string | null
  arena_variant:           null          // siempre null actualmente
  arena_state_model:       "keyword_heuristic + gpt-4o-mini" (arena) | null
  runtime_instructions:    string[] | null   // sellerNotes inyectadas
}
```

---

## AuditTurn (por turno)

```typescript
{
  turn_index:          number
  timestamp:           string
  mode:                "copilot" | "arena"
  source_mode:         string | null
  speaker_mode:        string | null
  raw_input:           string | null
  normalized_input:    string | null
  inferred_speaker:    string | null
  memory_before:       string[]
  model_request_summary: string | null
  model_output_raw:    string | null
  response_status:     "ok" | "error" | "partial"
  parse_error:         string | null
  notes:               string | null
  copilot?:            CopilotTurnData
  arena?:              ArenaTurnData
}
```

### CopilotTurnData
signal, say_now, avoid, reading, mission, next_move, support,  
journey_past, journey_now, journey_next, momentum, memory_after[], why_this_turn_exists

### ArenaTurnData
arena_role_of_user, ai_role_this_turn, user_message, ai_message,  
conversation_state_before, conversation_state_after,  
terminal_state_detected, terminal_state_type, terminal_state_source,  
tension_or_momentum, hidden_reasoning_summary,  
coach? { explanation }, journey? { stages, now_help, next_help, premature_close_risk }

---

## AuditHints (risk flags y anomalías)

```typescript
interface AuditHints {
  likely_primary_failure:                   string     // "seller"|"technical"|"system"|"none"
  suspected_prompt_issue:                   "yes"|"no"
  suspected_ui_issue:                       "yes"|"no"
  suspected_support_gap:                    "yes"|"no"
  suspected_close_timing_issue:             "yes"|"no"
  suspected_repetition_issue:               "yes"|"no"
  suspected_claim_risk:                     "yes"|"no"
  suspected_unresolved_technical_objection: "yes"|"no"
  suspected_false_confidence:               "yes"|"no"
  suspected_soft_next_step:                 "yes"|"no"
  audit_notes:                              string[]
}
```

---

## Detección de Risk Flags (Copiloto — `buildCopilotAuditLog`)

Heurística keyword-based sobre `finalMemory + signals + readings`. Conservadora, etiquetada como "suspected".

### CLAIM_RISK
Keywords: `garantía, certif, te aseguro, sin duda, 100% seguro, completamente seguro, guarantee, certified, i assure, no risk, 100% safe`  
Fuente: `allMemoryText`

### UNRESOLVED_TECHNICAL_OBJ
Condición: `isNextStep AND hasAnalyticalSignal AND NOT resolved/confirmed in memory`  
Analytical terms en signals/readings/memory: `analítico, técnic, dato, número, cifra, rentabilidad, metodología, roi, evidencia, data, numbers, methodology, return...`  
Negative indicators: `resuel*, resolved, confirmad*, confirmed`

### FALSE_CONFIDENCE
Keywords: `certif, homolog, regulad, oficial, certificate, certified, regulated, official, auditoría, audit`  
Fuente: `allMemoryText`

### SOFT_NEXT_STEP
Condición: `isNextStep AND NOT criterio/condition/criterion/acordad/agreed/compromi/commit in memory`

---

## Detección de Risk Flags (Arena — `buildArenaAuditLog`)

**IMPORTANTE:** En Arena, los 4 risk flags siempre son `"no"` en el builder.  
La detección real de risk flags en Arena ocurre en el endpoint `/api/arena/audit-report` (prompt del modelo), no en el builder del audit log.

---

## Secciones del Markdown generado (`renderAuditLogMarkdown`)

```markdown
# VELA AUDIT LOG

## SESSION_META
## SESSION_CONTEXT
## SESSION_CONFIG
## HIDDEN_RUNTIME_INSTRUCTIONS  (solo si hay sellerNotes)
## TURN_LOG
  ### TURN N
    #### COPILOT_ANALYSIS  (modo copiloto)
    #### ARENA_TURN         (modo arena)
      #### COACH_ANALYSIS   (si hay coach)
      #### JOURNEY_STATE    (si hay journey)
## READABLE_TRANSCRIPT
## SESSION_SUMMARY
## AUDIT_HINTS
```

---

## Lógica de `conversation_state` (Arena)

Función `deriveArenaState(text, lang)` — keyword-based:

**Critical (ES):** no me interesa, no puedo, imposible, demasiado caro, no voy a, no lo necesito, no me convence, descartado  
**Favorable (ES):** interesante, me gusta, cuéntame más, de acuerdo, vamos adelante, suena bien, perfecto, podría ser  
**Tense:** cualquier otro caso

---

## Audit notes automáticas (`auditNotes[]`)

Copiloto:
- X turno(s) con JSON parse errors
- X turno(s) con API errors
- X turnos consecutivos con mismo say_now (posible loop)
- outcome=lost → audit closing technique
- Sin outcome declarado
- Momentum final = red
- Sin turnos grabados
- CLAIM_RISK detectado
- UNRESOLVED_TECHNICAL_OBJ detectado
- FALSE_CONFIDENCE detectado
- SOFT_NEXT_STEP detectado

Arena:
- outcome=lost|broken → audit objection handling
- outcome=closed → ejemplo de sesión positiva
- Debrief score: X/10
- Exit note del usuario
- Conversación larga (>20 mensajes) → posibles issues de timing

---

## Nombre de archivo de descarga

```typescript
`cw-audit-${sessionId || appMode}-${timestamp}.md`
```
Ejemplo: `cw-audit-3f7a1234-2026-04-09T14-30-00.md`

Nota: el prefijo `cw-audit-` es legacy (no usa BRAND_NAME). Funcional pero no sigue la nomenclatura VELA.

---

## Momentum trend (Copiloto)

`detectMomentumTrend(turns)`: compara primer y último momentum con datos:
- `improving (amber → green)`
- `declining (green → red)`
- `stable (amber)`

Almacenado en `summary.final_momentum_or_state`.
