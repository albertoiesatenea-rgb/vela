# 01 — Estado actual de VELA

**Generado:** 2026-04-09 · Verificado contra código real en Replit

---

## Qué es VELA

Asistente táctico de llamadas de venta en tiempo real. Dos modos de uso independientes: Copiloto y Arena. Marca: VELA (constante `BRAND_NAME` exportada desde `audit-log.ts`).

---

## Modos activos

### Copiloto
- El usuario transcribe o dicta fragmentos de conversación real
- El sistema analiza cada fragmento y devuelve señal táctica JSON: `signal`, `say_now`, `avoid`, `detail`, `journey`, `call_memory`, `momentum`
- Dos sub-modos de entrada: **ESCUCHAR** (dictado Web Speech API) y **ESCRIBIR** (texto manual)
- Speaker mode: AUTO / CLIENTE / YO — determina quién habla en el fragmento
- Al terminar la llamada: flujo de outcome → resumen → score → reporte completo opcional → auditoría brutal opcional
- Descarga de audit log en `.md`

### Arena
- Simulación de conversación completa contra IA
- El usuario elige rol: **VENDEDOR** (enfrenta cliente IA) o **CLIENTE** (enfrenta vendedor IA)
- Perfiles configurables de cliente y vendedor, nivel de dificultad, presets de escenario
- IA abre la conversación con frase inicial generada
- Detección automática de estado terminal (closed / next_step / lost / broken)
- Al terminar: debrief con score 1-10 + 3 frases de crítica accionables
- CoachLite por turno (solo modo seller): anotación táctica del intercambio en 3 líneas
- Journey tracker (solo modo client): indicador de etapa del proceso de venta
- Instrucciones runtime ocultas (trainer puede inyectar restricciones al AI seller en tiempo real)
- Descarga de audit log en `.md`
- Informe de sesión copiable al clipboard

---

## Tech stack

| Capa | Tecnología |
|---|---|
| Frontend | React 18 + Vite + TypeScript |
| Backend | Express + TypeScript (Node.js) |
| Modelo AI | gpt-4o-mini (OpenAI) |
| Monorepo | pnpm workspaces |
| Estilos | Tailwind CSS (dark mode por defecto) |
| Iconos | lucide-react |
| Speech | Web Speech API (browser nativo) |

---

## Idiomas

Toggle EN/ES persistido en `localStorage` (`sc_lang`). Afecta a: prompts enviados al modelo, labels de UI, texto del audit log, informe de sesión.

---

## Estado funcional por área (abril 2026)

| Área | Estado |
|---|---|
| Copiloto analyze | ✅ Activo |
| Copiloto summarize | ✅ Activo |
| Copiloto audit-report (brutal) | ✅ Activo |
| Copiloto context-label | ✅ Activo |
| Arena start | ✅ Activo |
| Arena turn | ✅ Activo |
| Arena finish (debrief) | ✅ Activo |
| Arena terminal detection | ✅ Activo (optimizado con keyword heuristic) |
| Arena CoachLite | ✅ Activo (modo seller) |
| Arena Journey | ✅ Activo (modo client) |
| Arena preset-context | ✅ Activo |
| Arena adapt-context | ✅ Activo |
| Arena suggest | ✅ Activo |
| Arena audit-report | ✅ Activo |
| Download audit log (.md) | ✅ Activo |
| Debug panel AI monitor | ✅ Activo |
| Momentum indicator | ✅ Activo (green/amber/red) |
| Risk flags (4 tipos) | ✅ Activo (heurística + audit-report) |
| EN/ES toggle | ✅ Activo |

---

## Gaps conocidos (no son bugs — son limitaciones documentadas)

- `audit-report` (copilot) **no registra** llamada en `logAICall()` — no aparece en debug panel ni en totales de coste
- `coach-lite` y `journey` tienen `latencyMs` hardcodeado a `0` en `logAICall()` — latencia real no registrada
- `context.objective`, `context.known_objections`, `context.relevant_data` en audit log siempre son `null` — no se extraen automáticamente del contexto de sesión
- Arena risk flags (`suspected_claim_risk`, etc.) siempre son `"no"` en `buildArenaAuditLog()` — la detección heurística solo existe en el builder de Copiloto y en el endpoint `audit-report`
