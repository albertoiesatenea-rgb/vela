# 10 — Convenciones de escritura de prompts en VELA

**Generado:** 2026-04-09 · Verificado contra código real en Replit

Esta guía describe el estilo real observado en los prompts del código actual. No es teoría — es la convención activa que usa el proyecto.

---

## Principio base

Los prompts de VELA son **instrucciones de sistema operativas**, no texto didáctico. Se escriben como especificaciones técnicas. Sin metáforas, sin motivación, sin relleno. Cada línea debe ganarse su espacio.

---

## Estructura del sistema principal (Copiloto V2)

```
1. Rol en 1 frase — quién eres y qué haces
2. Schema JSON exacto — inline, sin markdown, con todos los campos
3. Diferenciación de campos — qué dice cada campo (≤ 1 línea por campo)
4. Clasificación previa obligatoria — tipos A/B/C con sus implicaciones
5. Reglas de detección — CLAIM_RISK, FALSE_CONFIDENCE, etc.
6. Regla anti-repetición — determina caso (1-5) antes de say_now
7. Bloques inyectados de sales-brain — OBJECTION_TAXONOMY, COMPARISON_RULE, etc.
8. Reglas de calidad por campo — say_now, avoid, support, call_memory, momentum
9. Regla final de formato — JSON puro, sin markdown
```

---

## Reglas de escritura observadas

### 1. Schema antes que reglas
El schema JSON siempre aparece al principio, completo, sin simplificar. El modelo debe verlo antes de leer las reglas.

### 2. NUNCA expliques el schema — describe cada campo
```
✓ "signal = TIPO de situación"
✓ "reading = QUÉ está pasando (diagnóstico)"
✗ "El campo signal sirve para clasificar el tipo de situación que se está viviendo en la conversación"
```

### 3. Diferencia obligatoria entre campos relacionados
Cuando dos campos tienen riesgo de solapamiento, la diferencia se documenta explícitamente:
```
LECTURA = qué está pasando
MISIÓN = qué necesitas conseguir
MOVIMIENTO = qué dices o haces
```

### 4. Contraste positivo/negativo en say_now
Siempre incluir ejemplos de lo BIEN (✓) y lo MAL (✗):
```
✓ "concreta si teme costes anuales o derramas"
✗ "explora sus preocupaciones"
```

### 5. Caps y prohibiciones explícitas
```
"PROHIBIDO: medias de mercado genéricas, porcentajes no mencionados en contexto"
"NUNCA inventar cifras"
"en caso de duda responde none"
```

### 6. Jerarquía de decisión cuando aplica
Si hay múltiples casos posibles, se listan en orden con numeración:
```
1. Cliente respondió CLARAMENTE → AVANZA
2. Respondió PARCIALMENTE → profundiza
3. EVITÓ responder → detecta evasión
4. Abrió FRENTE NUEVO → cambia eje
5. CAMBIÓ EJE → reorienta todo
```

### 7. Formato de output siempre al final
La instrucción de formato (JSON puro, sin markdown) va al final del system prompt, nunca intercalada.

---

## Longitudes de campo (reglas observadas)

| Campo | Restricción |
|---|---|
| signal | 2-5 palabras |
| say_now | 4-12 palabras, imperativo |
| avoid | 2-7 palabras o null |
| reading | ≤20 palabras |
| journey.past/next | 2-4 palabras |
| journey.now | 3-6 palabras |
| call_memory.summary_lines | 4-6 líneas, máx 6 |

---

## Prompts cortos (sub-llamadas)

### Terminal detection (5 tokens)
```
Una palabra. Definiciones estrictas. En caso de duda: none.
```

### CoachLite (280 tokens)
```
FORMATO OBLIGATORIO — exactamente 3 líneas, nada más:
Línea 1: **Nombre táctico** (bold, sin punto)
Línea 2: - acción del vendedor (≤7 palabras)
Línea 3: - por qué funciona (≤7 palabras)
```

### Context label (25 tokens)
```
4-6 palabras. Sin comillas, sin puntuación. Solo el título.
```

### Opening (150 tokens)
```
Una frase. Nombre+empresa inventados concretos. Varía el enfoque. Nunca expliques el producto.
```

---

## Inyecciones dinámicas

Todos los prompts largos admiten bloques inyectados al final del system prompt base:

1. **Contexto de sesión** → `CONTEXTO DE SESIÓN: <texto>` — solo si existe
2. **Regla de idioma** → `IDIOMA: La llamada es en español` o `LANGUAGE: The call is in English`
3. **Window note** (Arena) → nota de truncado de historial cuando aplica
4. **Preset block** (Arena) → descripción del preset inyectada si randomPreset activo
5. **Seller notes** (Arena, modo client) → `RESTRICCIONES DEL VENDEDOR: 1. ...`

---

## Debrief / Summarize — estilo de rúbrica

```
SCORING: rangos numéricos explícitos con sus condiciones
CAPS CONDICIONALES: aplica ANTES de puntuar
PENALIZACIONES: -1 a -2 c/u, con casos específicos
REFERENCIAS de score por outcome
```

---

## Audit report — estilo de auditoría

```
- Brutal, específico, accionable
- Si no hay evidencia, dilo. No rellenes huecos.
- Penaliza: vaguedad, objeciones sin resolver, cierres blandos
- failure_owner: classifica el origen del fallo
- what_i_would_have_done: alternativa táctica concreta, no vaga
```

---

## Bilingüismo

Todos los prompts tienen variante ES y EN. La variante se selecciona por `lang === "en"`.  
El modelo responde siempre en el idioma del prompt. Los valores JSON también cambian de idioma.

---

## Lo que NO se hace en los prompts de VELA

- No se usa markdown dentro de los prompts (sin `##`, sin listas con `*`)
- No se incluyen historias de ejemplo largas
- No se pide al modelo que "sea empático" o "sea amable"
- No se usan metáforas sobre el vendedor o el cliente
- No se dan instrucciones sobre el tono del modelo (excepto "sin etiquetas")
- No se incluye documentación de los campos que no es operativa
